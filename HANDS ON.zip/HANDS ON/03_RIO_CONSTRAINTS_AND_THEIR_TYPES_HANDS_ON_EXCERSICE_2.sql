drop table Student_Info;
create table Student_Info(
Reg_Number varchar(20) primary key,
Student_Name varchar(30) not null,
Branch varchar(30),
Contact_Number varchar(30),
Date_of_Birth varchar(15),
Date_of_joining datetime default current_timestamp
);

drop table Subject_Master;
create table Subject_Master(
Subject_Code varchar(20) primary key,
Subject_Name varchar(20) not null,
Weightage int not null
);

drop table Student_Marks;
create table Student_Marks(
Reg_Number varchar(20),
foreign key (Reg_Number) REFERENCES Student_Info(Reg_Number),
Subject_Code varchar(20),
foreign key (Subject_Code) REFERENCES Subject_Master(Subject_Code),
Semester int,
Marks int
);

drop table Student_Result;
create table Student_Result(
Reg_Number varchar(20),
foreign key (Reg_Number) REFERENCES Student_Info(Reg_Number),
Semester int,
GPA double,
Is_Eligible varchar(4) default 'yes'
);

alter table subject_master
modify Subject_Name varchar(20) not null unique;

alter table student_info
modify Contact_Number varchar(30) unique;

alter table student_info
ADD CHECK( Datediff(date_of_joining,date_of_birth)>0);
 
 alter table student_marks
ADD CHECK (Marks<=100);

alter table student_result
add check (GPA<=10);

alter table student_result
add check (Is_Eligible='Y' or Is_Eligible='N');