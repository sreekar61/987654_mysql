use ss;
select * from student_info;
select sinfo.student_name, sinfo.reg_number, sresult.GPA from student_info as sinfo
inner join student_result as sresult on sresult.Reg_Number = sinfo.Reg_Number
order by sresult.GPA desc;

select *from student_info order by student_name asc;


select * from student_result
group by Semester
having max(GPA);

select * from student_result
group by Semester
having min(GPA);






